Save N Serve — SaveNServe demo site (HTML/CSS/JS)
--------------------------------------------------
How to run:
1. Extract this folder.
2. Open in VS Code.
3. Install Live Server extension and click "Go Live" on index.html OR open index.html in browser.
4. To enable Google Maps: update scripts/config.js with your Google Maps JavaScript API key:
   replace GOOGLE_MAPS_API_KEY value.
