// config.js - put your Google Maps API key here
const GOOGLE_MAPS_API_KEY = "REPLACE_WITH_REAL_KEY";
/*
To use: in HTML include <script src="https://maps.googleapis.com/maps/api/js?key=REPLACE_WITH_REAL_KEY&callback=initMap" async defer></script>
Then the app.js initMap will pick up google.maps when loaded.
*/
