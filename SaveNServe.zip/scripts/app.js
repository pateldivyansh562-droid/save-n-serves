
// app.js - SaveNServe demo logic
const STORAGE_KEY = "savenserve_v3_demo";
const MAP_API_KEY = "REPLACE_WITH_YOUR_GOOGLE_MAPS_API_KEY"; // <<-- replace with your key in scripts/config.js if desired

const defaultData = {
  users:[
    {username:"student1", password:"1234", role:"student", name:"Student One"},
    {username:"staff", password:"1234", role:"staff", name:"Mess Staff"},
    {username:"ngo1", password:"1234", role:"ngo", name:"HelpingHands"}
  ],
  donations:[],
  requests:[],
  events:[],
  animalFeeds:[]
};

function initStorage(){
  if(!localStorage.getItem(STORAGE_KEY)) localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData));
}
function read(){ return JSON.parse(localStorage.getItem(STORAGE_KEY)); }
function write(d){ localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); }

/* auth */
function attemptLogin(u,p){
  const d = read();
  return d.users.find(x=>x.username===u && x.password===p) || null;
}
function signup(user){
  const d = read();
  d.users.push(user);
  write(d);
  return true;
}
function saveDonation(obj){
  const d = read();
  obj.id = Date.now();
  d.donations.unshift(obj);
  write(d);
}
function saveRequest(obj){
  const d = read();
  obj.id = Date.now();
  d.requests.unshift(obj);
  write(d);
}
function saveEvent(obj){
  const d = read();
  obj.id = Date.now();
  d.events.unshift(obj);
  write(d);
}
function saveAnimalFeed(obj){
  const d = read();
  obj.id = Date.now();
  d.animalFeeds.unshift(obj);
  write(d);
}

/* UI helpers */
function showToast(msg, time=2500){
  let t = document.getElementById('toast');
  if(!t){ t = document.createElement('div'); t.id='toast'; t.style.position='fixed'; t.style.right='20px'; t.style.bottom='20px'; t.style.background='linear-gradient(90deg,#0ea95d,#d4af37)'; t.style.color='white'; t.style.padding='10px 14px'; t.style.borderRadius='10px'; document.body.appendChild(t); }
  t.innerText = msg; t.style.display='block';
  setTimeout(()=> t.style.display='none', time);
}

/* render dashboard counters */
function renderDashboard(){
  const d = read();
  const meals = d.donations.reduce((s,it)=>s + (parseInt(it.qty)||0), 0);
  const requests = d.requests.length;
  const donations = d.donations.length;
  const ev = d.events.length;
  const mealsEl = document.getElementById('mealsSaved');
  if(mealsEl) mealsEl.innerText = meals;
  const donationsEl = document.getElementById('donationsCount');
  if(donationsEl) donationsEl.innerText = donations;
  const requestsEl = document.getElementById('requestsCount');
  if(requestsEl) requestsEl.innerText = requests;
  const eventsEl = document.getElementById('eventsCount');
  if(eventsEl) eventsEl.innerText = ev;
}

/* bind forms */
function bindForms(){
  const donateForm = document.getElementById('donationForm');
  if(donateForm){
    donateForm.addEventListener('submit', e=>{
      e.preventDefault();
      const donor = donateForm.donor.value || "Anonymous";
      const qty = donateForm.qty.value || 0;
      const location = donateForm.location.value || "Campus";
      saveDonation({donor, qty, location, time: new Date().toLocaleString()});
      donateForm.reset();
      showToast('Donation recorded (demo)');
      renderDashboard();
    });
  }
  const eventForm = document.getElementById('eventForm');
  if(eventForm){
    eventForm.addEventListener('submit', e=>{
      e.preventDefault();
      const obj = {organizer:eventForm.organizer.value, contact:eventForm.contact.value, servings:eventForm.servings.value, location:eventForm.location.value, time:new Date().toLocaleString()};
      saveEvent(obj);
      eventForm.reset();
      showToast('Event donation noted (demo)');
      renderDashboard();
    });
  }
  const requestForm = document.getElementById('requestForm');
  if(requestForm){
    requestForm.addEventListener('submit', e=>{
      e.preventDefault();
      const obj = {name:requestForm.name.value, org:requestForm.org.value, qty:requestForm.qty.value, location:requestForm.location.value, time:new Date().toLocaleString()};
      saveRequest(obj);
      requestForm.reset();
      showToast('Request submitted');
      renderDashboard();
    });
  }
  const feedForm = document.getElementById('feedForm');
  if(feedForm){
    feedForm.addEventListener('submit', e=>{
      e.preventDefault();
      const obj = {source:feedForm.source.value, qty:feedForm.qty.value, location:feedForm.location.value, time:new Date().toLocaleString()};
      saveAnimalFeed(obj);
      feedForm.reset();
      showToast('Animal feed request recorded');
      renderDashboard();
    });
  }
  const signupForm = document.getElementById('signupForm');
  if(signupForm){
    signupForm.addEventListener('submit', e=>{
      e.preventDefault();
      const user = {username:signupForm.username.value, password:signupForm.password.value, role:signupForm.role.value, name:signupForm.name.value};
      signup(user);
      signupForm.reset();
      showToast('Account created (demo)');
      window.location.href = 'login.html';
    });
  }
}

/* map init - uses Google Maps JS API if loaded; falls back to static */
function initMap(elementId='map'){
  const el = document.getElementById(elementId);
  if(!el) return;
  // If Google Maps API available
  if(window.google && google.maps){
    const map = new google.maps.Map(el, {center:{lat:28.7041,lng:77.1025},zoom:12});
    // simulate markers from stored donations/events/feeds
    const d = read();
    const sample = [
      {name:'HelpingHands NGO', lat:28.71, lng:77.11},
      {name:'Hope Kitchen', lat:28.7, lng:77.09},
      {name:'Animal Shelter A', lat:28.695, lng:77.12},
    ];
    sample.forEach(s=>{
      const m = new google.maps.Marker({position:{lat:s.lat,lng:s.lng},map, title:s.name});
      const inf = new google.maps.InfoWindow({content:`<strong>${s.name}</strong><br/>Demo marker`});
      m.addListener('click', ()=> inf.open(map,m));
    });
  } else {
    // fallback static message
    el.innerHTML = '<div style="display:grid;place-items:center;height:100%;color:#666">Map not available — set your Google Maps API key in scripts/config.js</div>';
  }
}

/* theme toggle */
function initTheme(){
  const saved = localStorage.getItem('sns_theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved==='dark' ? 'dark' : 'light');
  const btn = document.getElementById('themeBtn');
  if(btn) btn.addEventListener('click', ()=>{
    const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('sns_theme', next);
  });
}

/* init */
document.addEventListener('DOMContentLoaded', ()=>{
  initStorage();
  initTheme();
  bindForms();
  renderDashboard();
  // init map if present
  setTimeout(()=> initMap('map'), 600);
});
